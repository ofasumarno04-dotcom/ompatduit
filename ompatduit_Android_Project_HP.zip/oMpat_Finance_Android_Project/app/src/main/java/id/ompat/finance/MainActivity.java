package id.ompat.finance;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private DBHelper db;
    private LinearLayout root, list;
    private TextView incomeView, expenseView, balanceView;
    private final NumberFormat rupiah = NumberFormat.getCurrencyInstance(new Locale("id","ID"));
    private static final int EXPORT_CODE=21, IMPORT_CODE=22;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DBHelper(this);
        rupiah.setMaximumFractionDigits(0);
        build();
        refresh();
    }

    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(null,1); return t;
    }
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v,int n) { v.setPadding(dp(n),dp(n),dp(n),dp(n)); }
    private Button button(String label, Runnable action) {
        Button b=new Button(this); b.setText(label); b.setOnClickListener(v->action.run()); return b;
    }

    private void build() {
        ScrollView scroll=new ScrollView(this);
        root=vertical(); root.setBackgroundColor(0xFFF4F7FA); pad(root,16);
        scroll.addView(root); setContentView(scroll);

        TextView title=text("ompatduit",24,0xFF173B58,true); root.addView(title);
        TextView sub=text("Catatan keuangan pribadi • Offline-first",12,0xFF607080,false);
        root.addView(sub);

        LinearLayout card=vertical(); card.setBackgroundColor(0xFF173B58); pad(card,18);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(16);
        root.addView(card,cp);
        TextView balLabel=text("SALDO BERSIH TERCATAT",12,0xFFD6E5EF,true); card.addView(balLabel);
        balanceView=text("Rp0",28,0xFFFFFFFF,true); card.addView(balanceView);
        LinearLayout totals=horizontal(); totals.setPadding(0,dp(12),0,0); card.addView(totals);
        LinearLayout inc=vertical(), exp=vertical();
        incomeView=text("Masuk\nRp0",14,0xFFD8F2E1,true);
        expenseView=text("Keluar\nRp0",14,0xFFFFDADA,true);
        totals.addView(incomeView,new LinearLayout.LayoutParams(0,-2,1));
        totals.addView(expenseView,new LinearLayout.LayoutParams(0,-2,1));

        TextView actions=text("TRANSAKSI",14,0xFF173B58,true);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2); ap.topMargin=dp(20); ap.bottomMargin=dp(4);
        root.addView(actions,ap);
        LinearLayout row=horizontal(); root.addView(row);
        row.addView(button("+ Pemasukan",()->showAdd("Pemasukan")),new LinearLayout.LayoutParams(0,-2,1));
        row.addView(button("+ Pengeluaran",()->showAdd("Pengeluaran")),new LinearLayout.LayoutParams(0,-2,1));

        TextView recent=text("RIWAYAT TERBARU",14,0xFF173B58,true);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.topMargin=dp(16); rp.bottomMargin=dp(6);
        root.addView(recent,rp);
        list=vertical(); root.addView(list);

        TextView backupTitle=text("DATA & BACKUP",14,0xFF173B58,true);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(18);
        root.addView(backupTitle,bp);
        root.addView(button("Backup database ke Google Drive",()->exportDb()));
        root.addView(button("Pulihkan backup dari file",()->importDb()));
        TextView note=text("Backup akan membuat file database. Pilih Google Drive pada pemilih file untuk menyimpannya. Pemulihan akan mengganti data lokal dengan isi backup.",11,0xFF607080,false);
        note.setPadding(0,dp(6),0,dp(10)); root.addView(note);
    }

    private void refresh() {
        double in=db.total("Pemasukan"), out=db.total("Pengeluaran");
        incomeView.setText("Masuk\n"+rupiah.format(in));
        expenseView.setText("Keluar\n"+rupiah.format(out));
        balanceView.setText(rupiah.format(in-out));
        list.removeAllViews();
        Cursor c=db.all(); int count=0;
        while(c.moveToNext() && count<30) {
            String type=c.getString(2), cat=c.getString(3), note=c.getString(4);
            double amount=c.getDouble(5); long date=c.getLong(1);
            LinearLayout item=horizontal(); item.setBackgroundColor(count%2==0?0xFFFFFFFF:0xFFF8FAFC);
            item.setPadding(dp(10),dp(10),dp(10),dp(10));
            LinearLayout left=vertical();
            left.addView(text(cat+" • "+(note==null?"":note),14,0xFF263746,true));
            String ds=new SimpleDateFormat("dd MMM yyyy",new Locale("id","ID")).format(new Date(date));
            left.addView(text(ds+" • "+type,11,0xFF73808C,false));
            item.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            int color=type.equals("Pemasukan")?0xFF167447:0xFFB33A3A;
            item.addView(text((type.equals("Pemasukan")?"+":"-")+rupiah.format(amount),14,color,true));
            list.addView(item); count++;
        }
        c.close();
        if(count==0) list.addView(text("Belum ada transaksi. Tekan tombol pemasukan atau pengeluaran untuk mulai.",13,0xFF73808C,false));
    }

    private void showAdd(String type) {
        LinearLayout form=vertical(); pad(form,8);
        EditText amount=new EditText(this); amount.setHint("Nominal (contoh: 25000)"); amount.setInputType( android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); form.addView(amount);
        EditText category=new EditText(this); category.setHint("Kategori (contoh: Makan, Gaji, Cicilan)"); form.addView(category);
        EditText note=new EditText(this); note.setHint("Keterangan (opsional)"); form.addView(note);
        EditText account=new EditText(this); account.setHint("Akun (Tunai/Bank/E-wallet)"); account.setText("Tunai"); form.addView(account);
        new AlertDialog.Builder(this).setTitle("Tambah "+type).setView(form)
            .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
                try {
                    double val=Double.parseDouble(amount.getText().toString().trim().replace(",","."));
                    String cat=category.getText().toString().trim();
                    if(val<=0 || cat.isEmpty()) { toast("Nominal dan kategori wajib diisi"); return; }
                    db.add(System.currentTimeMillis(),type,cat,note.getText().toString().trim(),val,account.getText().toString().trim());
                    refresh(); toast("Transaksi tersimpan");
                } catch(Exception e) { toast("Nominal belum benar"); }
            }).show();
    }

    private void exportDb() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE,"oMpat_Finance_Backup.db");
        startActivityForResult(i,EXPORT_CODE);
    }
    private void importDb() {
        new AlertDialog.Builder(this).setTitle("Pulihkan backup?")
            .setMessage("Data transaksi lokal saat ini akan diganti oleh isi file backup yang dipilih. Pastikan sudah membuat backup terbaru.")
            .setNegativeButton("Batal",null).setPositiveButton("Lanjut pilih file",(d,w)->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*"); startActivityForResult(i,IMPORT_CODE);
            }).show();
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(res!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        try {
            if(req==EXPORT_CODE) {
                db.close();
                try(InputStream in=new FileInputStream(getDatabasePath(DBHelper.DB_NAME));
                    OutputStream out=getContentResolver().openOutputStream(uri)) {
                    byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
                }
                db=new DBHelper(this); toast("Backup berhasil disimpan");
            } else if(req==IMPORT_CODE) {
                db.close();
                try(InputStream in=getContentResolver().openInputStream(uri);
                    OutputStream out=new FileOutputStream(getDatabasePath(DBHelper.DB_NAME),false)) {
                    byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
                }
                db=new DBHelper(this); refresh(); toast("Backup dipulihkan");
            }
        } catch(Exception e) {
            db=new DBHelper(this);
            toast("Gagal memproses backup: "+e.getMessage());
        }
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
