package id.ompat.finance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "ompat_finance.db";
    public DBHelper(Context c) { super(c, DB_NAME, null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER NOT NULL, type TEXT NOT NULL, category TEXT NOT NULL, note TEXT, amount REAL NOT NULL, account TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}

    public long add(long date, String type, String category, String note, double amount, String account) {
        ContentValues v = new ContentValues();
        v.put("date", date); v.put("type", type); v.put("category", category);
        v.put("note", note); v.put("amount", amount); v.put("account", account);
        return getWritableDatabase().insert("transactions", null, v);
    }
    public Cursor all() {
        return getReadableDatabase().rawQuery("SELECT id,date,type,category,note,amount,account FROM transactions ORDER BY date DESC,id DESC", null);
    }
    public double total(String type) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=?", new String[]{type});
        double v=0; if(c.moveToFirst()) v=c.getDouble(0); c.close(); return v;
    }
    public void clearAll() { getWritableDatabase().delete("transactions", null, null); }
}
