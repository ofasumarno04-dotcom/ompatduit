# ompatduit — Android project (MVP)

Aplikasi Android native sederhana untuk mencatat pemasukan/pengeluaran secara offline, menyimpan data di SQLite lokal, dan backup/pulihkan file database melalui Android file picker (pilih Google Drive sebagai lokasi).

## Fitur MVP saat ini
- Dashboard: total pemasukan, pengeluaran, dan saldo bersih dari semua transaksi.
- Tambah pemasukan dan pengeluaran dengan kategori, keterangan, nominal, dan akun.
- Riwayat 30 transaksi terbaru.
- Database lokal SQLite.
- Backup database ke penyimpanan pilihan (termasuk Google Drive jika aplikasi Drive tersedia).
- Pulihkan database dari file backup.

## Build APK
1. Instal Android Studio versi terbaru di komputer.
2. Ekstrak folder project ini.
3. Android Studio > Open > pilih folder `oMpat_Finance_Android_Project`.
4. Tunggu Gradle sync dan instal Android SDK Platform 35 jika diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Ini project sumber Android, belum merupakan APK yang sudah dikompilasi.
- Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle, sehingga APK tidak dapat dibangun dan diuji di sini.
- Backup Drive menggunakan file picker: pengguna memilih lokasi Google Drive dan menyimpan file backup. Ini bukan sinkronisasi otomatis dua arah.
- Pulihkan backup akan mengganti database lokal. Buat backup baru sebelum memulihkan.
- MVP ini belum memuat modul anggaran, utang, tabungan, grafik, dan laporan; modul tersebut menjadi tahap pengembangan berikutnya.
