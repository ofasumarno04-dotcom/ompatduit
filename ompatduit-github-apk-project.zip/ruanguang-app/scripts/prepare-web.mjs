import { mkdir, copyFile } from 'node:fs/promises';

const files = ['index.html', 'manifest.json', 'sw.js', 'icon.svg', 'icon-192.png', 'icon-512.png'];
await mkdir('www', { recursive: true });
for (const file of files) await copyFile(file, `www/${file}`);
console.log('Prepared oMpatduit web assets in www/.');
