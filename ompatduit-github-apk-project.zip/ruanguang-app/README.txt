oMpatduit - aplikasi keuangan pribadi

Fitur prototipe terintegrasi Firebase:
- Login Google melalui Firebase Authentication
- Sinkronisasi data aplikasi ke Firestore pada users/{uid}/appData/main
- Data lokal tetap tersedia saat belum login/offline; sinkronisasi cloud saat login dan online
- Backup dan restore JSON

PENTING:
1. Hosting harus menggunakan HTTPS dan domain harus diizinkan di Firebase Authentication > Settings > Authorized domains.
2. Pastikan Firestore Rules mengizinkan hanya UID pemilik data.
3. Jangan gunakan data keuangan penting sebelum menguji login, sinkronisasi, logout, dan restore pada perangkat kedua.
4. Google sign-in popup mungkin tidak berfungsi pada beberapa browser mobile; redirect digunakan sebagai fallback.

File index.html menggunakan Firebase Web SDK 13.4.0 dan konfigurasi project oMpatduit.
