# Build APK oMpatduit liwat GitHub Actions

Project iki nambah pipeline Android menyang aplikasi web oMpatduit sing wis ana. Foto asli sing dikirim digunakake dadi sumber launcher icon; file gambar mung diskalakake menyang ukuran aset, ora dicrop utawa ditambahi efek.

## Cara nggunakake
1. Upload kabeh isi folder `ruanguang-app` iki menyang repository GitHub anyar utawa repository aplikasi oMpatduit sing wis ana.
2. Priksa manawa `index.html`, `manifest.json`, `sw.js`, `firebase.json`, lan `.firebaserc` tetep ana ing root repository.
3. Ing GitHub, bukak tab **Actions**.
4. Pilih **Build oMpatduit Android APK**, banjur pencet **Run workflow**. Push menyang `main` utawa `master` uga otomatis miwiti build.
5. Yen build sukses, bukak run paling anyar, gulung menyang **Artifacts**, banjur download `oMpatduit-android-debug-apk`.
6. Extract ZIP artifact lan instal `app-debug.apk` ing Android kanggo tes.

## Cathetan penting
- Iki APK debug kanggo tes, durung APK release sing ditandatangani kanggo publikasi Play Store.
- APK iki mbungkus web app sing ana ing `index.html`; Firebase project config tetep padha.
- Google Authentication ing WebView/native Android bisa mbutuhake konfigurasi tambahan lan uji nyata. Authorized domains Firebase Hosting wae durung mesthi cukup kanggo alur OAuth ing aplikasi native. Tes login sadurunge nggunakake data keuangan nyata.
- Firestore Rules kudu tetep mbatesi akses mung marang UID pemilik data.
- Yen pengin rilis Play Store, gawe signing key lan simpen kredensial minangka GitHub Actions Secrets; aja commit keystore utawa password menyang repository.
