import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ompatduit.app',
  appName: 'oMpatduit',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
